var class_operating_mode =
[
    [ "OperatingMode", "class_operating_mode.html#a00a42c9213ae07402deac3024bedd195", null ],
    [ "createLogDirectory", "class_operating_mode.html#aae725af7e46f40e92412f328c769c6cf", null ],
    [ "drawElements", "class_operating_mode.html#a46dd30d4bd5155bb4f3480a9719d6d37", null ],
    [ "drawMenuBar", "class_operating_mode.html#a5da4d22c90750577a0a5777ccf074f8c", null ],
    [ "run", "class_operating_mode.html#a8c7295cd3f7e9c281b8a069148366dde", null ],
    [ "setupShortcuts", "class_operating_mode.html#aeeea1156e43f3af06d7dd5b0cb44874b", null ],
    [ "switchTemplate", "class_operating_mode.html#a32905fb8285a6b6ac9f4373857a87f17", null ],
    [ "currentTemplateIndex", "class_operating_mode.html#a31a562c4d92de3cb76d073aaec468077", null ],
    [ "templateManager", "class_operating_mode.html#aa69b5b5d8fc7cdbe1f12affda07c44d5", null ]
];