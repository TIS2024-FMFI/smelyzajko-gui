var searchData=
[
  ['settingvalue_0',['SettingValue',['../_element_8h.html#ac34800f1f3633cdb7eb1e4e38182cc62',1,'Element.h']]],
  ['shortcutcallback_1',['ShortcutCallback',['../class_shortcuts_manager.html#aea0d9b65a572817f93a70a431a8307f4',1,'ShortcutsManager']]]
];
