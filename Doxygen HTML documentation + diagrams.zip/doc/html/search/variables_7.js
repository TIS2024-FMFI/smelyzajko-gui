var searchData=
[
  ['hodnota1_0',['hodnota1',['../class_counter_module.html#afab1bd160a1266ad7ceb75e8da2b8ff4',1,'CounterModule']]],
  ['hodnota2_1',['hodnota2',['../class_counter_module.html#aea777e29eed715f566cc6594df8585e4',1,'CounterModule']]]
];
