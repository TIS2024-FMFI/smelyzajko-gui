var searchData=
[
  ['debounce_5fms_0',['DEBOUNCE_MS',['../class_shortcuts_manager.html#a61367b9c2ee7ce91547360c7df8caaff',1,'ShortcutsManager']]],
  ['deltatime_1',['deltaTime',['../class_map_module.html#a3f6d93b189f424853c6d2d37c0ee40b0',1,'MapModule::deltaTime'],['../class_ultrasonic_module.html#a79a168f5dd797cbcbf84ad62e891cee6',1,'UltrasonicModule::deltaTime']]],
  ['distance_2',['distance',['../struct_ultrasonic_sensor_data.html#a960a8b1c12def9adbb89f40bdfb1f403',1,'UltrasonicSensorData']]]
];
