var _configuration_mode_8cpp =
[
    [ "findFreePosition", "_configuration_mode_8cpp.html#ab038b0faebd75789ba2eaece6421add3", null ],
    [ "findNearestFreeGridCorner", "_configuration_mode_8cpp.html#a2715a5d2c0c25eb341119e6476fb7fab", null ],
    [ "isOverlapping", "_configuration_mode_8cpp.html#ab15a8efc75f200e48464003a245e8d94", null ]
];