var struct_slider_settings =
[
    [ "SliderSettings", "struct_slider_settings.html#a5eb5583477fb2b6a0b1e060398c30b26", null ],
    [ "SliderSettings", "struct_slider_settings.html#a07eea9ab3483404d38e9246ae11e7fcb", null ],
    [ "initialValue", "struct_slider_settings.html#a18f923ffc8e2d01995a80d5fc22e3f42", null ],
    [ "isHorizontal", "struct_slider_settings.html#ac389b312e7eed5bb6df76d59ee7f780d", null ],
    [ "label", "struct_slider_settings.html#a82b970acfc47838cab1337b400074993", null ],
    [ "maxValue", "struct_slider_settings.html#a70291416f807261b1008105951db5ef3", null ],
    [ "minValue", "struct_slider_settings.html#aafd77eb9363d8fa4351ad2de0f864aef", null ]
];