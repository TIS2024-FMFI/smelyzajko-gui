var class_template_manager =
[
    [ "TemplateManager", "class_template_manager.html#a0b5e0f6e28baacee1a96a3c4f7aca988", null ],
    [ "TemplateManager", "class_template_manager.html#a8cd0ba1e72a42064c0c2890d4e779d28", null ],
    [ "TemplateManager", "class_template_manager.html#a5c6456f2be4c9e92747333e564e619e3", null ],
    [ "addElementToActiveTemplate", "class_template_manager.html#a4564bcd51c31b4124b38cb3d092ee7de", null ],
    [ "addModuleToActiveTemplate", "class_template_manager.html#ab03470f3dca61879b4182101ed479d3b", null ],
    [ "clearActiveTemplateElements", "class_template_manager.html#afa7953d5b0d68f6f9c7d6ad5af7baf46", null ],
    [ "getActiveTemplate", "class_template_manager.html#ab5ac80b1fd0469e4a52a767b05bcb7a8", null ],
    [ "getActiveTemplateElements", "class_template_manager.html#a8d382c747163ca8af9c897bb8e9a276b", null ],
    [ "getActiveTemplateModules", "class_template_manager.html#af0b33bf5b8425e1528da6ca1fc8ea1ae", null ],
    [ "getActiveTemplateName", "class_template_manager.html#a3ca8b37c1a41576f616a1697efceb2db", null ],
    [ "getAllTemplates", "class_template_manager.html#aca9cf661ead4696ab8b5c7e3058b045c", null ],
    [ "loadAllTemplates", "class_template_manager.html#a24f416f0d6b254aca92412fba6642d1c", null ],
    [ "loadTemplates", "class_template_manager.html#a54836921dff0220af842ff13319daa45", null ],
    [ "removeElementFromActiveTemplate", "class_template_manager.html#acb00272230f431f41b0fd98a5134400a", null ],
    [ "setActiveTemplate", "class_template_manager.html#a761ffdbc3a3995efa822fec96336f29d", null ],
    [ "setConfigMode", "class_template_manager.html#a57f1b13676e5c26fd641b26baa7744ed", null ],
    [ "activeTemplate", "class_template_manager.html#aab9b00f208bd45bc0570eb4ef05a3564", null ],
    [ "allTemplates", "class_template_manager.html#a3a910a75ded6167d1168abb5e4180c7c", null ],
    [ "configMode", "class_template_manager.html#a22ce5fe896a46149c03eabce2868e88b", null ]
];