var class_template =
[
    [ "Template", "class_template.html#a64e7e096339458e69d43502f1d125db0", null ],
    [ "Template", "class_template.html#abbd9c9c286ca00077b7bef99e0ab6f5e", null ],
    [ "addElement", "class_template.html#aa5d1991a51237503b7a8a165701be7e8", null ],
    [ "addModule", "class_template.html#affc16615b72d587c8246cc510496a2ba", null ],
    [ "clear", "class_template.html#a0593ca466d360d874f94050c5a3a35c1", null ],
    [ "from_json", "class_template.html#a5f04806369b3a4c0ddf043be2034be5f", null ],
    [ "getElements", "class_template.html#a1ce3399011adce1f7d87831f4e64ed7f", null ],
    [ "getModules", "class_template.html#a099d95334df3f553126c5196397daf33", null ],
    [ "getName", "class_template.html#ab060ad67145e1c001f02b7e40766fde5", null ],
    [ "loadTemplate", "class_template.html#acc49077e32c84f0734c439b2d1ac7b77", null ],
    [ "removeElement", "class_template.html#a603c32ae6125cdabbbf91b78b2925199", null ],
    [ "saveTemplate", "class_template.html#a89b190b227ca378b8f08171a775e167b", null ],
    [ "to_json", "class_template.html#a2bc2390e560d34dc055af5b5227121e2", null ],
    [ "configurationMode", "class_template.html#a2ee0faf8397da2156bc4604d25f6e5df", null ],
    [ "elements", "class_template.html#acafdcbc51e7b7d2f634bc3b6abe906a6", null ],
    [ "graphicModules", "class_template.html#a6ab10120df2203d68aa88adb5cd534f7", null ],
    [ "name", "class_template.html#a0bf965812f43ad48634b0d0436a431a5", null ],
    [ "resolution", "class_template.html#a26ad485a3e9f6951fc679f30d2ffe42a", null ]
];