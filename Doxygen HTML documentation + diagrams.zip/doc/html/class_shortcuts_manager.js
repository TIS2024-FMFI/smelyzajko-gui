var class_shortcuts_manager =
[
    [ "ShortcutCallback", "class_shortcuts_manager.html#aea0d9b65a572817f93a70a431a8307f4", null ],
    [ "ShortcutsManager", "class_shortcuts_manager.html#a3392ef3db8d39b1a89d54cfb69c6d2f7", null ],
    [ "ShortcutsManager", "class_shortcuts_manager.html#a2e537a885a808c14acf9fcb641dd6486", null ],
    [ "getGlfwKey", "class_shortcuts_manager.html#a2a7f7434645f65341504892da26cb574", null ],
    [ "isShortcutPressed", "class_shortcuts_manager.html#a2d521c6b34f87c51cfd355f7954934da", null ],
    [ "parseShortcut", "class_shortcuts_manager.html#a17b5235ad99537ce966065e004272960", null ],
    [ "processShortcuts", "class_shortcuts_manager.html#a35063ec3d7ffe8faf4a3f0b01ddfb778", null ],
    [ "registerShortcut", "class_shortcuts_manager.html#adf49f48c118af8170f376e04243800d3", null ],
    [ "setWindow", "class_shortcuts_manager.html#ae4b8d2da91fbb80002c337a3ec0b1f22", null ],
    [ "DEBOUNCE_MS", "class_shortcuts_manager.html#a61367b9c2ee7ce91547360c7df8caaff", null ],
    [ "lastActivationTimes", "class_shortcuts_manager.html#a8cdf1b41c10cb2635340e9abbc3b31f3", null ],
    [ "shortcuts", "class_shortcuts_manager.html#a97037253ef6030f90e849063db1d0877", null ],
    [ "window", "class_shortcuts_manager.html#a7c84baea8f83143c31fe6dd03351d2ba", null ]
];