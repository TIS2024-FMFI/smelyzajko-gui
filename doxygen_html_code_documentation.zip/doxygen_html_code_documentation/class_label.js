var class_label =
[
    [ "Label", "class_label.html#a1bb576e446b3facca24881563832cb32", null ],
    [ "createTextSizeButton", "class_label.html#aac4daf23123a0452dc78de7756d90c9d", null ],
    [ "draw", "class_label.html#ad9cc9aec3c9188fc0360ee96c7fb4305", null ],
    [ "from_json", "class_label.html#a1254708ed5b32e1a0d44f49293e64f32", null ],
    [ "getBoundingBox", "class_label.html#a21a05ba0c4bff4d432c349225cf67edd", null ],
    [ "getSettings", "class_label.html#a2de2a602951cdc80432dfa769c4b70df", null ],
    [ "getText", "class_label.html#a84b972514f4996181995cdde56976228", null ],
    [ "handleClicks", "class_label.html#a135ef240e8afc371a2cc1afede8996b3", null ],
    [ "setText", "class_label.html#add3f5dfed876e0a4f16e8365a8d7f05b", null ],
    [ "font_size", "class_label.html#a2db4d72ea0ae60f7baaaa6f0b4b9d570", null ]
];