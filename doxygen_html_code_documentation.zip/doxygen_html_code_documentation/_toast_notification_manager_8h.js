var _toast_notification_manager_8h =
[
    [ "ToastNotificationManager", "class_toast_notification_manager.html", "class_toast_notification_manager" ],
    [ "ToastNotificationManager::Notification", "struct_toast_notification_manager_1_1_notification.html", "struct_toast_notification_manager_1_1_notification" ]
];