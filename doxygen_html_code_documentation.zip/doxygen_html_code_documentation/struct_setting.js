var struct_setting =
[
    [ "name", "struct_setting.html#ae3f03c868cd14b6cf3964426df4b5918", null ],
    [ "setter", "struct_setting.html#a51dedad0eb4b9098125e9d67afc70f0a", null ],
    [ "value", "struct_setting.html#a126a49d4aa69ef84784ed4f5ba0b210a", null ]
];