var class_g_u_i =
[
    [ "GUI", "class_g_u_i.html#aacd0e4ec975213d74fa4bf76b03bfecb", null ],
    [ "cleanupImGui", "class_g_u_i.html#a6f5622ec1b0b3e8526e0eb897e88d210", null ],
    [ "loadModules", "class_g_u_i.html#ae97e08402cf1a0d66de572b1d2438cc5", null ],
    [ "run", "class_g_u_i.html#a5fbce226084a6360a57694cc9523e4c5", null ],
    [ "setupImGui", "class_g_u_i.html#a048f24dd2ed1d09c8398a5948a024c1d", null ],
    [ "setupShortcuts", "class_g_u_i.html#addb054d936da6d942c0595e0d56669a6", null ],
    [ "configFile", "class_g_u_i.html#af756e2ce5c7cfb63deef8de372888c0b", null ],
    [ "io", "class_g_u_i.html#ad3f4b2dac62c7196abd8a05b2597a120", null ],
    [ "moduleManager", "class_g_u_i.html#ad08c7cf4bf7154b302d4978dd4c754be", null ],
    [ "monitorHeight", "class_g_u_i.html#a667dc85400d3f58f4192455c20b6218c", null ],
    [ "monitorWidth", "class_g_u_i.html#a7163a534d4ff81b901e02da8a1af0ca7", null ],
    [ "primaryMonitor", "class_g_u_i.html#ae0957fdc3f89e6cc253ea37c7fecf5f5", null ],
    [ "shortcutsManager", "class_g_u_i.html#a6ca6e2655f2f4d289bc9828445b73b8b", null ],
    [ "toastManager", "class_g_u_i.html#a748c8ee2885b8f6370814e4603f14494", null ],
    [ "window", "class_g_u_i.html#a2955f39e8b9690cf35a43a8b0768f64f", null ]
];