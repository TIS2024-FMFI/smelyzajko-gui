var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvwyz~",
  1: "bceghlmnorstuv",
  2: "bceghlmorstuv",
  3: "abcdefghilmoprstuv~",
  4: "abcdefghilmnprstuvwz",
  5: "js",
  6: "my"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

