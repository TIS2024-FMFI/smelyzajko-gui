var searchData=
[
  ['updatedelayms_0',['updateDelayMs',['../class_ultrasonic_module.html#a5cb7b2861948ac53bf797e2274119d1f',1,'UltrasonicModule']]],
  ['updateintervalframes_1',['updateIntervalFrames',['../class_ultrasonic_module.html#a27484a5e286d1e02257404656786d68d',1,'UltrasonicModule']]]
];
