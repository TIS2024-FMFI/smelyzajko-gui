var searchData=
[
  ['resolution_0',['resolution',['../class_template.html#a26ad485a3e9f6951fc679f30d2ffe42a',1,'Template']]],
  ['rows_1',['rows',['../class_map_module.html#aa35fd0afe34b9ed3b0f3fafa2d84d88c',1,'MapModule::rows'],['../class_map_module_graphics.html#a599e34203dd770210f01648ec55582cc',1,'MapModuleGraphics::rows']]],
  ['running_2',['running',['../class_map_module.html#a949468cd8192be735b067f932a1b39eb',1,'MapModule::running'],['../class_ultrasonic_module.html#abf33c51a9d52c9e78245e7df51b6f659',1,'UltrasonicModule::running']]]
];
