var _template_manager_8h =
[
    [ "TemplateManager", "class_template_manager.html", "class_template_manager" ]
];