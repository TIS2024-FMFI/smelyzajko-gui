var class_text_area =
[
    [ "TextArea", "class_text_area.html#af298ce42ff6f8233052e516c00e8f122", null ],
    [ "clearLogs", "class_text_area.html#a51baf226481e0d9f96d757859b383377", null ],
    [ "draw", "class_text_area.html#a3b1690295dc75ed274133921202cfda7", null ],
    [ "isAutoscrollEnabled", "class_text_area.html#a556711e968392dfb99e941808eb99f1b", null ],
    [ "logToJson", "class_text_area.html#a5d2375288ae9261ca2077d89e18aa5dd", null ],
    [ "setAutoscrollEnabled", "class_text_area.html#af13fcd53edcd51700fe762f86c0ae8bd", null ],
    [ "updateValueOfModule", "class_text_area.html#ac1d5e26b4dbb3d42d0d60e1bcda7d04c", null ],
    [ "autoscrollEnabled", "class_text_area.html#a7226d422586d49db3d867f50882df675", null ],
    [ "logMutex", "class_text_area.html#a1949ee2a9b9e5f8ae90f0db1aaf30891", null ],
    [ "logs", "class_text_area.html#a4b89da292484b66b6667ac0a3c5e6833", null ],
    [ "scrollbar", "class_text_area.html#ae375935bfcfd64155ccd45a2d2fcd33f", null ]
];