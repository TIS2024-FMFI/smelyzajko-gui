var class_module =
[
    [ "~Module", "class_module.html#af09dc286b704160d8f0f273e1fe8576b", null ],
    [ "getModuleID", "class_module.html#accb1e0d12ef8fe448a2f9c1c7d49f4e5", null ],
    [ "getModuleName", "class_module.html#a0d9c4e6333e976bb67e977b5cc65ae1c", null ],
    [ "getPossibleGraphicsElement", "class_module.html#a9c9b1b6f6f337596aff7cf750be89d85", null ],
    [ "getPossibleInputElements", "class_module.html#ad38cd2c2d310a7ed095ea5fe74f9f7c5", null ],
    [ "registerShortcuts", "class_module.html#a3c92d538a02c372b4a95d0648ee27b30", null ],
    [ "run", "class_module.html#a070aa407caa2fff85973381ca6652ccb", null ],
    [ "setModuleID", "class_module.html#a5e580e3c8fc48eca851031915a71e603", null ],
    [ "setModuleName", "class_module.html#ad104aeefcc7f14fbe0692836286242e0", null ],
    [ "setValueFromInputElements", "class_module.html#adfb31aa51ae298729f3d24e1e137c7f2", null ],
    [ "setValueFromInputElements", "class_module.html#a2e3cc9546ae8bb5ceecc8944c921d5d8", null ],
    [ "setValueFromInputElements", "class_module.html#a53cc7310edcdb71c2d7ec48a39b7b6d4", null ],
    [ "setValueFromInputElements", "class_module.html#aacfedddd733febed5da16ffb09f28d84", null ],
    [ "setValueFromInputElements", "class_module.html#a59790ad9fcaee286b8556d3a32155d72", null ],
    [ "moduleId", "class_module.html#a6f158702ac54e6e567abf65b9dc9595d", null ],
    [ "moduleName", "class_module.html#a0861dfadc5239b727f9e494ddac0497f", null ]
];