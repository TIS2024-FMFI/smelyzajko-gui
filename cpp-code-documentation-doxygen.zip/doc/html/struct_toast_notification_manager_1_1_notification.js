var struct_toast_notification_manager_1_1_notification =
[
    [ "is_open", "struct_toast_notification_manager_1_1_notification.html#a37cd4a746cf297c3a77d225f909ad535", null ],
    [ "message", "struct_toast_notification_manager_1_1_notification.html#a5b0c8e7df9210f2ff5bf8efdb3f44f4b", null ],
    [ "start_time", "struct_toast_notification_manager_1_1_notification.html#a7eb9f8922695755276feaf4008b755df", null ],
    [ "title", "struct_toast_notification_manager_1_1_notification.html#ac186660130763661df2dd646421cb801", null ]
];