var class_multi_line_label =
[
    [ "MultiLineLabel", "class_multi_line_label.html#a57fa80b50b2a28d030f4b0c4a4f68485", null ],
    [ "draw", "class_multi_line_label.html#a36a253213f061a962c67db9cf02814e8", null ],
    [ "from_json", "class_multi_line_label.html#a9051f190001d79964ef4e4b3f824f79a", null ],
    [ "to_json", "class_multi_line_label.html#a7d944891d4b203aa56cabfbf2962cea2", null ]
];