var struct_ultrasonic_sensor_data =
[
    [ "angle", "struct_ultrasonic_sensor_data.html#aa2d6a4bd3765a0e723b9114531dfceef", null ],
    [ "distance", "struct_ultrasonic_sensor_data.html#a960a8b1c12def9adbb89f40bdfb1f403", null ]
];