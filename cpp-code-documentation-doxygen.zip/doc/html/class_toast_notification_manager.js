var class_toast_notification_manager =
[
    [ "Notification", "struct_toast_notification_manager_1_1_notification.html", "struct_toast_notification_manager_1_1_notification" ],
    [ "addNotification", "class_toast_notification_manager.html#aef50e91ebe21d1db14456a0dfaeacc8f", null ],
    [ "renderNotifications", "class_toast_notification_manager.html#ad7b05434842387ed632f27e4c068ad9c", null ],
    [ "notifications", "class_toast_notification_manager.html#a4c8154d34e897cf087968eff63beedb3", null ],
    [ "timeout", "class_toast_notification_manager.html#ac15353a85da6a1959ddf40704ce34d82", null ]
];