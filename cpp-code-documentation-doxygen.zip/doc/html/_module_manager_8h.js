var _module_manager_8h =
[
    [ "ModuleManager", "class_module_manager.html", "class_module_manager" ],
    [ "MODULEMANAGER_H", "_module_manager_8h.html#a02754c5e52ae42d959728746d778382f", null ]
];