var _shortcuts_manager_8h =
[
    [ "ShortcutsManager", "class_shortcuts_manager.html", "class_shortcuts_manager" ]
];