var class_module_manager =
[
    [ "clearModules", "class_module_manager.html#ab949f35e9db4d9a152abf4f1d9a0c036", null ],
    [ "getInstance", "class_module_manager.html#a5c5498e95a703e2568824d6394bbccfa", null ],
    [ "getModuleConstructors", "class_module_manager.html#ac2dd04c42f1585b837e9cb01e6e2f98f", null ],
    [ "getModules", "class_module_manager.html#a01855802f6653105c6178125c084066b", null ],
    [ "registerGraphicModule", "class_module_manager.html#abacde6c024ec11d380c1f5f02f918306", null ],
    [ "registerModule", "class_module_manager.html#a5f6a0729cf93969a601dc33f6f0630e0", null ],
    [ "setActiveModuleAndDraw", "class_module_manager.html#aed2481d720d2b7284424154d1129021d", null ],
    [ "setLogDirectory", "class_module_manager.html#a840d6db00e2e68ccb95eb4cfb2d0628a", null ],
    [ "setValueFromInputElements", "class_module_manager.html#a841fc8a5632f5e1d4481070886211492", null ],
    [ "setValueFromInputElements", "class_module_manager.html#aeb00113c59dde776d32855ff0c7bf7cf", null ],
    [ "setValueFromInputElements", "class_module_manager.html#a494f7af59cc0e028b84b638b752a3ae3", null ],
    [ "setValueFromInputElements", "class_module_manager.html#a6768dac8578bc0e7c1e8310d9c2045f1", null ],
    [ "updateValueOfModule", "class_module_manager.html#a184010496bdca917c18523632f12457f", null ],
    [ "updateValueOfModule", "class_module_manager.html#a2ad274654fd6934fb02f82d9425f75c8", null ],
    [ "updateValueOfModule", "class_module_manager.html#aba6a8e168e4d62b8f4dc4b74fb24cfa6", null ],
    [ "updateValueOfModule", "class_module_manager.html#a6ca5db7007713e3309e0b28c99232b22", null ],
    [ "graphicModules", "class_module_manager.html#a3f3605ed57a8ff5a30b37b41e512737f", null ],
    [ "logDirectory", "class_module_manager.html#a8a363c4fb7e8e30453522dd2b3823e6a", null ],
    [ "moduleConstructors", "class_module_manager.html#a85a3c77563c8406c6f8f115d2a57bcba", null ],
    [ "modules", "class_module_manager.html#a24b26d499c025437f868a0c113361b46", null ]
];