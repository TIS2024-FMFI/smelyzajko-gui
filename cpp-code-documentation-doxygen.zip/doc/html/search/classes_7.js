var searchData=
[
  ['notification_0',['Notification',['../struct_toast_notification_manager_1_1_notification.html',1,'ToastNotificationManager']]]
];
