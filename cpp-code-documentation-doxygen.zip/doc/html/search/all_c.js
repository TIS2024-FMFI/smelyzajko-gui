var searchData=
[
  ['name_0',['name',['../class_template.html#a0bf965812f43ad48634b0d0436a431a5',1,'Template::name'],['../struct_setting.html#ae3f03c868cd14b6cf3964426df4b5918',1,'Setting::name']]],
  ['notification_1',['Notification',['../struct_toast_notification_manager_1_1_notification.html',1,'ToastNotificationManager']]],
  ['notifications_2',['notifications',['../class_toast_notification_manager.html#a4c8154d34e897cf087968eff63beedb3',1,'ToastNotificationManager']]]
];
