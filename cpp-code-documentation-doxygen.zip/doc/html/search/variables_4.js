var searchData=
[
  ['elements_0',['elements',['../class_template.html#acafdcbc51e7b7d2f634bc3b6abe906a6',1,'Template']]]
];
